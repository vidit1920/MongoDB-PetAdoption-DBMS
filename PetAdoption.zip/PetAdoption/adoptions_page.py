# adoptions_page.py
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from bson import ObjectId

from db import get_db

BG_DARK = "#111827"
CARD_DARK = "#1F2933"
ACCENT = "#38BDF8"
TEXT = "#E5E7EB"


def open_adoptions_page(parent):
    db = get_db()
    adoptions_col = db["adoptions"]
    pets_col = db["pets"]
    adopters_col = db["adopters"]

    win = tk.Toplevel(parent)
    win.title("Manage Adoptions")
    win.geometry("900x500")
    win.configure(bg=BG_DARK)

    style = ttk.Style(win)
    style.theme_use("clam")
    style.configure(
        "Treeview",
        background=CARD_DARK,
        foreground=TEXT,
        fieldbackground=CARD_DARK,
        rowheight=22,
        font=("Segoe UI", 9),
    )
    style.configure("Treeview.Heading",
                    background="#020617",
                    foreground=ACCENT,
                    font=("Segoe UI Semibold", 9))
    style.configure("Dark.TButton",
                    background=ACCENT,
                    foreground="#020617",
                    font=("Segoe UI", 9, "bold"),
                    padding=4)
    style.map("Dark.TButton",
              background=[("active", "#0EA5E9")])

    top = tk.Frame(win, bg=CARD_DARK)
    top.pack(fill="x", padx=10, pady=10)

    tk.Label(top, text="Create Adoption", bg=CARD_DARK, fg=ACCENT,
             font=("Segoe UI Semibold", 12)).grid(row=0, column=0,
                                                  columnspan=4, pady=(4, 10))

    tk.Label(top, text="Adopter:", bg=CARD_DARK, fg=TEXT).grid(row=1, column=0, padx=5)
    adopter_cmb = ttk.Combobox(top, width=25, state="readonly")
    adopter_cmb.grid(row=1, column=1, padx=5)

    tk.Label(top, text="Pet:", bg=CARD_DARK, fg=TEXT).grid(row=1, column=2, padx=5)
    pet_cmb = ttk.Combobox(top, width=25, state="readonly")
    pet_cmb.grid(row=1, column=3, padx=5)

    tk.Label(top, text="Adoption Date (YYYY-MM-DD):",
             bg=CARD_DARK, fg=TEXT).grid(row=2, column=0, padx=5, pady=8)
    date_e = tk.Entry(top, bg=BG_DARK, fg=TEXT,
                      insertbackground=TEXT, relief="flat", width=18)
    date_e.grid(row=2, column=1, padx=5)

    def load_dropdowns():
        adopters = list(adopters_col.find().sort("name", 1))
        pets = list(pets_col.find({"status": {"$ne": "Adopted"}}).sort("name", 1))

        adopter_map.clear()
        pet_map.clear()

        adopter_cmb["values"] = []
        pet_cmb["values"] = []

        a_vals = []
        for a in adopters:
            label = f'{a.get("name","")} <{a.get("email","")}>'
            a_vals.append(label)
            adopter_map[label] = str(a["_id"])
        adopter_cmb["values"] = a_vals

        p_vals = []
        for p in pets:
            label = f'{p.get("name","")} ({p.get("species","")})'
            p_vals.append(label)
            pet_map[label] = str(p["_id"])
        pet_cmb["values"] = p_vals

    adopter_map = {}
    pet_map = {}

    def create_adoption():
        adopter_label = adopter_cmb.get()
        pet_label = pet_cmb.get()
        if not adopter_label or not pet_label:
            messagebox.showerror("Missing", "Select adopter and pet.")
            return
        adopter_id = adopter_map.get(adopter_label)
        pet_id = pet_map.get(pet_label)

        date_str = date_e.get().strip() or datetime.today().strftime("%Y-%m-%d")
        try:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Invalid date", "Use format YYYY-MM-DD.")
            return

        # Insert adoption
        adoptions_col.insert_one(
            {
                "adopter_id": ObjectId(adopter_id),
                "pet_id": ObjectId(pet_id),
                "date": date_obj,
            }
        )
        # Mark pet as adopted
        pets_col.update_one({"_id": ObjectId(pet_id)}, {"$set": {"status": "Adopted"}})

        load_dropdowns()
        refresh_table()
        date_e.delete(0, "end")

    ttk.Button(top, text="Create Adoption",
               style="Dark.TButton",
               command=create_adoption).grid(row=2, column=2, padx=5, pady=8)

    # Table
    columns = ("_id", "adopter", "pet", "date")
    tree = ttk.Treeview(win, columns=columns, show="headings")
    for c in columns:
        tree.heading(c, text=c.upper())
    tree.column("_id", width=180)
    tree.column("adopter", width=200)
    tree.column("pet", width=200)
    tree.column("date", width=100)
    tree.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def refresh_table():
        for r in tree.get_children():
            tree.delete(r)

        # Simple manual "join" in Python
        adopters_index = {str(a["_id"]): a for a in adopters_col.find()}
        pets_index = {str(p["_id"]): p for p in pets_col.find()}

        for ad in adoptions_col.find().sort("date", -1):
            aid = str(ad.get("adopter_id"))
            pid = str(ad.get("pet_id"))
            adopter = adopters_index.get(aid, {})
            pet = pets_index.get(pid, {})

            tree.insert(
                "",
                "end",
                iid=str(ad["_id"]),
                values=(
                    str(ad["_id"]),
                    adopter.get("name", "") + " <" + adopter.get("email", "") + ">",
                    pet.get("name", "") + " (" + pet.get("species", "") + ")",
                    ad.get("date").strftime("%Y-%m-%d") if ad.get("date") else "",
                )
            )

    load_dropdowns()
    refresh_table()
