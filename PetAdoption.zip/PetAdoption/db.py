# db.py
from pymongo import MongoClient
from pymongo.errors import PyMongoError

# ====== EDIT THIS ONLY: put your real password in the URI ======
MONGO_URI = (
    "mongodb+srv://gvidit18_db_user:Beastuu7449"
    "@cluster0.3xqb5f7.mongodb.net/?appName=Cluster0"
)
DB_NAME = "PetAdoption"  # your database name


_client = None
_db = None


def get_db():
    """
    Returns a connected MongoDB database object.
    """
    global _client, _db
    if _db is None:
        try:
            _client = MongoClient(MONGO_URI)
            _db = _client[DB_NAME]
            _init_indexes(_db)
        except PyMongoError as e:
            raise SystemExit(f"Could not connect to MongoDB: {e}")
    return _db


def _init_indexes(db):
    """
    Create indexes once. Called automatically.
    - Unique email for adopters.
    """
    try:
        db["adopters"].create_index("email", unique=True)
    except PyMongoError:
        # If index already exists or something minor fails, just continue.
        pass
