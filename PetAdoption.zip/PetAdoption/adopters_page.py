# adopters_page.py
import tkinter as tk
from tkinter import ttk, messagebox
from bson import ObjectId

from db import get_db

BG_DARK = "#111827"
CARD_DARK = "#1F2933"
ACCENT = "#38BDF8"
TEXT = "#E5E7EB"


def open_adopters_page(parent):
    db = get_db()
    adopters_col = db["adopters"]
    adoptions_col = db["adoptions"]

    win = tk.Toplevel(parent)
    win.title("Manage Adopters")
    win.geometry("750x480")
    win.configure(bg=BG_DARK)

    style = ttk.Style(win)
    style.theme_use("clam")
    style.configure(
        "Treeview",
        background=CARD_DARK,
        foreground=TEXT,
        fieldbackground=CARD_DARK,
        rowheight=22,
        font=("Segoe UI", 9),
    )
    style.configure("Treeview.Heading",
                    background="#020617",
                    foreground=ACCENT,
                    font=("Segoe UI Semibold", 9))
    style.configure("Dark.TButton",
                    background=ACCENT,
                    foreground="#020617",
                    font=("Segoe UI", 9, "bold"),
                    padding=4)
    style.map("Dark.TButton",
              background=[("active", "#0EA5E9")])

    left = tk.Frame(win, bg=CARD_DARK)
    left.pack(side="left", fill="y", padx=10, pady=10)

    tk.Label(left, text="Add / Update Adopter",
             bg=CARD_DARK, fg=ACCENT,
             font=("Segoe UI Semibold", 12)).pack(pady=(5, 10))

    def make_row(text):
        f = tk.Frame(left, bg=CARD_DARK)
        f.pack(anchor="w", pady=3)
        tk.Label(f, text=text, bg=CARD_DARK, fg=TEXT,
                 font=("Segoe UI", 9)).pack(anchor="w")
        e = tk.Entry(f, bg=BG_DARK, fg=TEXT, insertbackground=TEXT,
                     width=26, relief="flat")
        e.pack()
        return e

    name_e = make_row("Name")
    email_e = make_row("Email")
    address_e = make_row("Address")

    btn_frame = tk.Frame(left, bg=CARD_DARK)
    btn_frame.pack(pady=10)

    selected_id = {"_id": None}

    def clear_form():
        name_e.delete(0, "end")
        email_e.delete(0, "end")
        address_e.delete(0, "end")
        selected_id["_id"] = None

    def add_adopter():
        name = name_e.get().strip()
        email = email_e.get().strip().lower()
        addr = address_e.get().strip()

        if not name or not email:
            messagebox.showerror("Missing", "Name and email are required.")
            return

        try:
            adopters_col.insert_one(
                {"name": name, "email": email, "address": addr}
            )
        except Exception as e:
            if "duplicate key" in str(e).lower():
                messagebox.showerror(
                    "Duplicate email",
                    "This email is already registered."
                )
            else:
                messagebox.showerror("Error", str(e))
            return

        refresh_table()
        clear_form()

    def update_adopter():
        if not selected_id["_id"]:
            messagebox.showwarning("No selection", "Select an adopter first.")
            return
        name = name_e.get().strip()
        email = email_e.get().strip().lower()
        addr = address_e.get().strip()

        if not name or not email:
            messagebox.showerror("Missing", "Name and email are required.")
            return

        try:
            adopters_col.update_one(
                {"_id": ObjectId(selected_id["_id"])},
                {"$set": {"name": name, "email": email, "address": addr}},
            )
        except Exception as e:
            if "duplicate key" in str(e).lower():
                messagebox.showerror(
                    "Duplicate email",
                    "Another adopter already uses this email."
                )
            else:
                messagebox.showerror("Error", str(e))
            return
        refresh_table()

    def delete_adopter():
        if not selected_id["_id"]:
            messagebox.showwarning("No selection", "Select an adopter first.")
            return

        # Do not allow delete if they have adoptions
        count = adoptions_col.count_documents(
            {"adopter_id": ObjectId(selected_id["_id"])}
        )
        if count > 0:
            messagebox.showerror(
                "Cannot delete",
                "This adopter is linked to adoptions. Delete those first."
            )
            return

        if messagebox.askyesno("Confirm", "Delete this adopter?"):
            adopters_col.delete_one({"_id": ObjectId(selected_id["_id"])})
            refresh_table()
            clear_form()

    ttk.Button(btn_frame, text="Add", style="Dark.TButton",
               command=add_adopter).grid(row=0, column=0, padx=3)
    ttk.Button(btn_frame, text="Update", style="Dark.TButton",
               command=update_adopter).grid(row=0, column=1, padx=3)
    ttk.Button(btn_frame, text="Delete", style="Dark.TButton",
               command=delete_adopter).grid(row=0, column=2, padx=3)
    ttk.Button(btn_frame, text="Clear", style="Dark.TButton",
               command=clear_form).grid(row=0, column=3, padx=3)

    right = tk.Frame(win, bg=BG_DARK)
    right.pack(side="left", fill="both", expand=True, padx=(0, 10), pady=10)

    # Simple name/email filter
    filter_frame = tk.Frame(right, bg=BG_DARK)
    filter_frame.pack(fill="x")
    tk.Label(filter_frame, text="Search:",
             bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).grid(row=0, column=0, padx=4)
    search_e = tk.Entry(filter_frame, bg=CARD_DARK, fg=TEXT,
                        insertbackground=TEXT, relief="flat", width=20)
    search_e.grid(row=0, column=1, padx=4)

    def refresh_table():
        q = {}
        term = search_e.get().strip()
        if term:
            q["$or"] = [
                {"name": {"$regex": term, "$options": "i"}},
                {"email": {"$regex": term, "$options": "i"}},
            ]

        for r in tree.get_children():
            tree.delete(r)

        for doc in adopters_col.find(q).sort("name", 1):
            tree.insert(
                "",
                "end",
                iid=str(doc["_id"]),
                values=(
                    str(doc["_id"]),
                    doc.get("name", ""),
                    doc.get("email", ""),
                    doc.get("address", ""),
                )
            )

    ttk.Button(filter_frame, text="Refresh",
               style="Dark.TButton",
               command=refresh_table).grid(row=0, column=2, padx=4)

    columns = ("_id", "name", "email", "address")
    tree = ttk.Treeview(right, columns=columns, show="headings")
    for c in columns:
        tree.heading(c, text=c.upper())
    tree.column("_id", width=180)
    tree.column("name", width=120)
    tree.column("email", width=150)
    tree.column("address", width=180)

    tree.pack(fill="both", expand=True, pady=(8, 0))

    def on_select(event):
        sel = tree.focus()
        if not sel:
            return
        vals = tree.item(sel, "values")
        selected_id["_id"] = vals[0]
        name_e.delete(0, "end")
        name_e.insert(0, vals[1])
        email_e.delete(0, "end")
        email_e.insert(0, vals[2])
        address_e.delete(0, "end")
        address_e.insert(0, vals[3])

    tree.bind("<<TreeviewSelect>>", on_select)

    refresh_table()
