# pets_page.py
import tkinter as tk
from tkinter import ttk, messagebox
from bson import ObjectId

from db import get_db

BG_DARK = "#111827"
CARD_DARK = "#1F2933"
ACCENT = "#38BDF8"
TEXT = "#E5E7EB"
ERROR = "#F97373"


def open_pets_page(parent):
    db = get_db()
    pets_col = db["pets"]

    win = tk.Toplevel(parent)
    win.title("Manage Pets")
    win.geometry("900x520")
    win.configure(bg=BG_DARK)

    style = ttk.Style(win)
    style.theme_use("clam")
    style.configure(
        "Treeview",
        background=CARD_DARK,
        foreground=TEXT,
        fieldbackground=CARD_DARK,
        rowheight=22,
        font=("Segoe UI", 9),
    )
    style.configure("Treeview.Heading",
                    background="#111827",
                    foreground=ACCENT,
                    font=("Segoe UI Semibold", 9))
    style.map("Treeview",
              background=[("selected", "#0EA5E9")])
    style.configure("Dark.TButton",
                    background=ACCENT,
                    foreground="#020617",
                    font=("Segoe UI", 9, "bold"),
                    padding=4)
    style.map("Dark.TButton",
              background=[("active", "#0EA5E9")])

    # ===== Left form =====
    left = tk.Frame(win, bg=CARD_DARK)
    left.pack(side="left", fill="y", padx=10, pady=10)

    tk.Label(left, text="Add / Update Pet",
             bg=CARD_DARK, fg=ACCENT,
             font=("Segoe UI Semibold", 12)).pack(pady=(5, 10))

    def make_row(text):
        frame = tk.Frame(left, bg=CARD_DARK)
        frame.pack(anchor="w", pady=3)
        lab = tk.Label(frame, text=text, bg=CARD_DARK, fg=TEXT,
                       font=("Segoe UI", 9))
        lab.pack(side="top", anchor="w")
        entry = tk.Entry(frame, bg=BG_DARK, fg=TEXT,
                         insertbackground=TEXT, width=26,
                         relief="flat")
        entry.pack(side="top", pady=1)
        return entry

    name_e = make_row("Name")
    species_e = make_row("Species")
    age_e = make_row("Age")
    gender_e = make_row("Gender (Male/Female/Other)")
    status_e = make_row("Status (Available/Adopted)")

    # Buttons
    btn_frame = tk.Frame(left, bg=CARD_DARK)
    btn_frame.pack(pady=10)

    selected_id = {"_id": None}

    def clear_form():
        name_e.delete(0, "end")
        species_e.delete(0, "end")
        age_e.delete(0, "end")
        gender_e.delete(0, "end")
        status_e.delete(0, "end")
        selected_id["_id"] = None

    def add_pet():
        try:
            name = name_e.get().strip()
            species = species_e.get().strip()
            age = int(age_e.get().strip())
            gender = gender_e.get().strip()
            status = status_e.get().strip() or "Available"
        except ValueError:
            messagebox.showerror("Invalid", "Age must be an integer.")
            return
        if not name or not species:
            messagebox.showerror("Missing", "Name and species are required.")
            return

        doc = {
            "name": name,
            "species": species,
            "age": age,
            "gender": gender,
            "status": status,
        }
        pets_col.insert_one(doc)
        refresh_table()
        clear_form()

    def update_pet():
        if not selected_id["_id"]:
            messagebox.showwarning("No selection", "Select a pet from the table.")
            return
        try:
            age = int(age_e.get().strip())
        except ValueError:
            messagebox.showerror("Invalid", "Age must be an integer.")
            return
        update = {
            "name": name_e.get().strip(),
            "species": species_e.get().strip(),
            "age": age,
            "gender": gender_e.get().strip(),
            "status": status_e.get().strip() or "Available",
        }
        pets_col.update_one(
            {"_id": ObjectId(selected_id["_id"])},
            {"$set": update},
        )
        refresh_table()

    def delete_pet():
        from db import get_db  # just in case
        if not selected_id["_id"]:
            messagebox.showwarning("No selection", "Select a pet to delete.")
            return

        # Prevent deleting if used in adoptions
        adoptions_col = get_db()["adoptions"]
        count = adoptions_col.count_documents({"pet_id": ObjectId(selected_id["_id"])})
        if count > 0:
            messagebox.showerror(
                "Cannot delete",
                "This pet is referenced in adoptions. Delete those first."
            )
            return

        if messagebox.askyesno("Confirm", "Delete selected pet?"):
            pets_col.delete_one({"_id": ObjectId(selected_id["_id"])})
            refresh_table()
            clear_form()

    ttk.Button(btn_frame, text="Add", style="Dark.TButton",
               command=add_pet).grid(row=0, column=0, padx=4)
    ttk.Button(btn_frame, text="Update", style="Dark.TButton",
               command=update_pet).grid(row=0, column=1, padx=4)
    ttk.Button(btn_frame, text="Delete", style="Dark.TButton",
               command=delete_pet).grid(row=0, column=2, padx=4)
    ttk.Button(btn_frame, text="Clear", style="Dark.TButton",
               command=clear_form).grid(row=0, column=3, padx=4)

    # Distinct species demo (DBMS DISTINCT)
    def show_distinct_species():
        species_list = pets_col.distinct("species")
        msg = "\n".join(str(s) for s in species_list) or "No species yet."
        messagebox.showinfo("Distinct Species", msg)

    ttk.Button(left, text="Show Distinct Species",
               style="Dark.TButton",
               command=show_distinct_species).pack(pady=(5, 0))

    # ===== Right side: filters + table =====
    right = tk.Frame(win, bg=BG_DARK)
    right.pack(side="left", fill="both", expand=True, padx=(0, 10), pady=10)

    # Filters
    filter_frame = tk.Frame(right, bg=BG_DARK)
    filter_frame.pack(fill="x")

    tk.Label(filter_frame, text="Search Name:",
             bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).grid(row=0, column=0, padx=4)
    search_name_e = tk.Entry(filter_frame, bg=CARD_DARK, fg=TEXT,
                             insertbackground=TEXT, relief="flat", width=16)
    search_name_e.grid(row=0, column=1, padx=4)

    tk.Label(filter_frame, text="Species:",
             bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).grid(row=0, column=2, padx=4)
    species_filter_e = tk.Entry(filter_frame, bg=CARD_DARK, fg=TEXT,
                                insertbackground=TEXT, relief="flat", width=10)
    species_filter_e.grid(row=0, column=3, padx=4)

    tk.Label(filter_frame, text="Age between:",
             bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).grid(row=1, column=0, padx=4, pady=4)
    age_min_e = tk.Entry(filter_frame, bg=CARD_DARK, fg=TEXT,
                         insertbackground=TEXT, relief="flat", width=6)
    age_min_e.grid(row=1, column=1, padx=4)
    tk.Label(filter_frame, text="and",
             bg=BG_DARK, fg=TEXT).grid(row=1, column=2)
    age_max_e = tk.Entry(filter_frame, bg=CARD_DARK, fg=TEXT,
                         insertbackground=TEXT, relief="flat", width=6)
    age_max_e.grid(row=1, column=3, padx=4)

    tk.Label(filter_frame, text="Sort by:",
             bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).grid(row=0, column=4, padx=4)
    sort_field_cmb = ttk.Combobox(filter_frame, values=["name", "species", "age"],
                                  width=10, state="readonly")
    sort_field_cmb.set("name")
    sort_field_cmb.grid(row=0, column=5, padx=4)

    sort_dir_cmb = ttk.Combobox(filter_frame, values=["Ascending", "Descending"],
                                width=11, state="readonly")
    sort_dir_cmb.set("Ascending")
    sort_dir_cmb.grid(row=0, column=6, padx=4)

    tk.Label(filter_frame, text="Limit:",
             bg=BG_DARK, fg=TEXT, font=("Segoe UI", 9)).grid(row=1, column=4, padx=4)
    limit_e = tk.Entry(filter_frame, bg=CARD_DARK, fg=TEXT,
                       insertbackground=TEXT, relief="flat", width=6)
    limit_e.grid(row=1, column=5, padx=4)

    def refresh_table():
        # Build query
        query = {}
        name = search_name_e.get().strip()
        if name:
            query["name"] = {"$regex": name, "$options": "i"}

        sp = species_filter_e.get().strip()
        if sp:
            query["species"] = {"$regex": f"^{sp}$", "$options": "i"}

        try:
            age_min = int(age_min_e.get()) if age_min_e.get().strip() else None
            age_max = int(age_max_e.get()) if age_max_e.get().strip() else None
        except ValueError:
            messagebox.showerror("Invalid", "Age range must be integers.")
            return

        if age_min is not None or age_max is not None:
            query["age"] = {}
            if age_min is not None:
                query["age"]["$gte"] = age_min
            if age_max is not None:
                query["age"]["$lte"] = age_max

        sort_field = sort_field_cmb.get()
        sort_dir = 1 if sort_dir_cmb.get() == "Ascending" else -1

        cursor = pets_col.find(query).sort(sort_field, sort_dir)

        try:
            limit_n = int(limit_e.get()) if limit_e.get().strip() else None
        except ValueError:
            messagebox.showerror("Invalid", "Limit must be an integer.")
            return

        if limit_n:
            cursor = cursor.limit(limit_n)

        for row in tree.get_children():
            tree.delete(row)

        for doc in cursor:
            tree.insert(
                "",
                "end",
                iid=str(doc["_id"]),
                values=(
                    str(doc["_id"]),
                    doc.get("name", ""),
                    doc.get("species", ""),
                    doc.get("age", ""),
                    doc.get("gender", ""),
                    doc.get("status", ""),
                )
            )

    ttk.Button(filter_frame, text="Apply / Refresh",
               style="Dark.TButton",
               command=refresh_table).grid(row=1, column=6, padx=4)

    # Treeview
    columns = ("_id", "name", "species", "age", "gender", "status")
    tree = ttk.Treeview(right, columns=columns, show="headings")
    for col in columns:
        tree.heading(col, text=col.upper())
    tree.column("_id", width=180)
    tree.column("name", width=120)
    tree.column("species", width=100)
    tree.column("age", width=60, anchor="center")
    tree.column("gender", width=80)
    tree.column("status", width=90)

    tree.pack(fill="both", expand=True, pady=(8, 0))

    def on_select(event):
        sel = tree.focus()
        if not sel:
            return
        vals = tree.item(sel, "values")
        selected_id["_id"] = vals[0]
        name_e.delete(0, "end")
        name_e.insert(0, vals[1])
        species_e.delete(0, "end")
        species_e.insert(0, vals[2])
        age_e.delete(0, "end")
        age_e.insert(0, vals[3])
        gender_e.delete(0, "end")
        gender_e.insert(0, vals[4])
        status_e.delete(0, "end")
        status_e.insert(0, vals[5])

    tree.bind("<<TreeviewSelect>>", on_select)

    refresh_table()
