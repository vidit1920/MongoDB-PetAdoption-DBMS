# main.py
import tkinter as tk
from tkinter import ttk

from pets_page import open_pets_page
from adopters_page import open_adopters_page
from adoptions_page import open_adoptions_page

BG_DARK = "#111827"
CARD_DARK = "#1F2933"
ACCENT = "#38BDF8"
TEXT = "#E5E7EB"


def main():
    root = tk.Tk()
    root.title("PetAdoption – DBMS Mini Project")
    root.geometry("520x420")
    root.configure(bg=BG_DARK)

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("TButton",
                    background=ACCENT,
                    foreground="#0B1120",
                    font=("Segoe UI", 11, "bold"),
                    padding=6)
    style.map("TButton",
              background=[("active", "#0EA5E9")])

    # Title
    title = tk.Label(
        root,
        text="🐾 PetAdoption",
        font=("Segoe UI Semibold", 22),
        bg=BG_DARK,
        fg=ACCENT,
    )
    title.pack(pady=(30, 4))

    subtitle = tk.Label(
        root,
        text="Dark UI • Manage Pets, Adopters & Adoptions (MongoDB + Tkinter)",
        font=("Segoe UI", 9),
        bg=BG_DARK,
        fg=TEXT,
    )
    subtitle.pack(pady=(0, 25))

    # Card frame
    card = tk.Frame(root, bg=CARD_DARK, bd=0, highlightthickness=0)
    card.pack(padx=30, pady=10, fill="x")

    btn_frame = tk.Frame(card, bg=CARD_DARK)
    btn_frame.pack(padx=40, pady=25, fill="x")

    btn_w = 26

    ttk.Button(
        btn_frame,
        text="Manage Pets",
        width=btn_w,
        command=lambda: open_pets_page(root),
    ).pack(pady=8)

    ttk.Button(
        btn_frame,
        text="Manage Adopters",
        width=btn_w,
        command=lambda: open_adopters_page(root),
    ).pack(pady=8)

    ttk.Button(
        btn_frame,
        text="Manage Adoptions",
        width=btn_w,
        command=lambda: open_adoptions_page(root),
    ).pack(pady=8)

    footer = tk.Label(
        root,
        text="Made with ❤️ using MongoDB Atlas, PyMongo, Tkinter",
        font=("Segoe UI", 8),
        bg=BG_DARK,
        fg="#6B7280",
    )
    footer.pack(side="bottom", pady=10)

    root.mainloop()


if __name__ == "__main__":
    main()
